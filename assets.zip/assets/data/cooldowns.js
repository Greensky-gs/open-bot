let cooldowns = new Map();

module.exports = cooldowns;